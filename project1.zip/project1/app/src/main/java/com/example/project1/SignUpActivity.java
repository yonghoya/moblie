package com.example.project1;

import android.content.Context;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;


public class SignUpActivity extends MainActivity{
    @Override
    protected  void onCreate(Bundle saveInstanceState){
        super.onCreate(saveInstanceState);
        setContentView(R.layout.activity_signup);

        Button cancelButton =(Button)findViewById(R.id.Cancel_Button);
        Button saveButton = (Button)findViewById(R.id.Save_Button);

        final EditText new_id_EditText = (EditText)findViewById(R.id.New_ID_EditText);
        final EditText new_pw_EditText = (EditText)findViewById(R.id.New_PW_EditText);
        final EditText new_address_EditText = (EditText)findViewById(R.id.New_ADRESS_EditText);
        final EditText new_name_EditText = (EditText)findViewById(R.id.New_NAME_EditText);
        final EditText new_del_EditText = (EditText)findViewById(R.id.New_Del_EditText);

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                finish();
            }
        });

    }
}
