package com.example.project1;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SignInActivity extends MainActivity {

    @Override
    protected void onCreate(Bundle saveInstanceState){
        super.onCreate(saveInstanceState);
        setContentView(R.layout.activity_signin);

        Button naver = (Button)findViewById(R.id.naver);
        Button daum = (Button)findViewById(R.id.daum);
        Button google = (Button)findViewById(R.id.google);
        Button nate = (Button)findViewById(R.id.nate);
        Button kakao = (Button)findViewById(R.id.kakao);
        Button nexon = (Button)findViewById(R.id.nexen);
        Button kookmin = (Button)findViewById(R.id.kookmin);
        Button lol = (Button)findViewById(R.id.lol);
        Button msn = (Button)findViewById(R.id.msn);
        naver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://m.naver.com"));
                startActivity(myIntent);
            }
        });

        daum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://m.daum.com"));
                startActivity(myIntent);
            }
        });

        google.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://m.google.com"));
                startActivity(myIntent);
            }
        });
        nate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://m.nate.com"));
                startActivity(myIntent);
            }
        });

        kakao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://kakaocorp.com"));
                startActivity(myIntent);
            }
        });
        nexon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://mobile.nexon.com"));
                startActivity(myIntent);
            }
        });
        kookmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://kookmin.ac.kr"));
                startActivity(myIntent);
            }
        });
        lol.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://na.leagueoflegends.com"));
                startActivity(myIntent);
            }
        });
        msn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://msn.com"));
                startActivity(myIntent);
            }
        });
    }
}
